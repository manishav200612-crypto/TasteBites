
package com.tastybites.CustomerService.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tastybites.CustomerService.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    // Check username and password for login
    Optional<Customer> findByUsernameAndPassword(
            String username,
            String password
    );

    // Check whether username already exists during registration
    boolean existsByUsername(String username);
}