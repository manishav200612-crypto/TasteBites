package com.tastybites.CustomerService.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.tastybites.CustomerService.entity.Customer;
import com.tastybites.CustomerService.repository.CustomerRepository;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    // Get all customers
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    // Add customer
    public Customer addCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    // Update customer
    public Customer updateCustomer(Long id, Customer customer) {
        customer.setId(id);
        return customerRepository.save(customer);
    }

    // Delete customer
    public void deleteCustomer(Long id) {
        customerRepository.deleteById(id);
    }

    // Register customer
    public Customer registerCustomer(Customer customer) {

        if (customerRepository.existsByUsername(customer.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        return customerRepository.save(customer);
    }

    // Login customer
    public Customer loginCustomer(String username, String password) {

        Optional<Customer> customer =
                customerRepository.findByUsernameAndPassword(username, password);

        if (customer.isPresent()) {
            return customer.get();
        }

        throw new RuntimeException("Invalid username or password");
    }
}