package com.tastybites.CustomerService.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tastybites.CustomerService.entity.Customer;
import com.tastybites.CustomerService.service.CustomerService;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    // Get all customers
    @GetMapping
    public List<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }

    // Add customer
    @PostMapping
    public Customer addCustomer(@RequestBody Customer customer) {
        return customerService.addCustomer(customer);
    }

    // Update customer
    @PutMapping("/{id}")
    public Customer updateCustomer(
            @PathVariable Long id,
            @RequestBody Customer customer) {

        return customerService.updateCustomer(id, customer);
    }

    // Delete customer
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {

        customerService.deleteCustomer(id);

        return ResponseEntity.ok("Customer deleted successfully");
    }

    // Register
    @PostMapping("/register")
    public ResponseEntity<Customer> registerCustomer(
            @RequestBody Customer customer) {

        Customer registeredCustomer =
                customerService.registerCustomer(customer);

        return ResponseEntity.ok(registeredCustomer);
    }

    // Login
    @PostMapping("/login")
    public ResponseEntity<Customer> loginCustomer(
            @RequestBody Customer loginRequest) {

        Customer customer =
                customerService.loginCustomer(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                );

        return ResponseEntity.ok(customer);
    }
}