package com.tastybites.RestaurantService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tastybites.RestaurantService.entity.Restaurant;

public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {

}