package com.tastybites.RestaurantService.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tastybites.RestaurantService.entity.Restaurant;
import com.tastybites.RestaurantService.repository.RestaurantRepository;

@Service
public class RestaurantService {

    private final RestaurantRepository restaurantRepository;

    public RestaurantService(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    // Get all restaurants
    public List<Restaurant> getAllRestaurants() {
        return restaurantRepository.findAll();
    }

    // Add restaurant
    public Restaurant addRestaurant(Restaurant restaurant) {
        return restaurantRepository.save(restaurant);
    }

    // Delete restaurant
    public void deleteRestaurant(Long id) {
        restaurantRepository.deleteById(id);
    }

    // Get restaurant by ID
    public Restaurant getRestaurantById(Long id) {
        return restaurantRepository.findById(id).orElse(null);
    }
 // Update restaurant rating
    public Restaurant updateRating(Long id, int rating) {

        Restaurant restaurant = getRestaurantById(id);

        if (restaurant == null) {
            return null;
        }

        int oldTotal = restaurant.getTotalReviews();
        double oldAverage = restaurant.getAverageRating();

        double newAverage =
                ((oldAverage * oldTotal) + rating)
                / (oldTotal + 1);

        restaurant.setAverageRating(
                Math.round(newAverage * 10.0) / 10.0
        );

        restaurant.setTotalReviews(oldTotal + 1);

        return restaurantRepository.save(restaurant);
    }
}