package com.tastybites.RestaurantService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
