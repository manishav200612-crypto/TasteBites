package com.tastybites.ContactService.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.tastybites.ContactService.entity.ContactMessage;
import com.tastybites.ContactService.repository.ContactMessageRepository;

@Service
public class ContactMessageService {

    private final ContactMessageRepository repository;

    public ContactMessageService(ContactMessageRepository repository) {
        this.repository = repository;
    }

    public List<ContactMessage> getAllMessages() {
        return repository.findAll();
    }

    public ContactMessage addMessage(ContactMessage message) {
        return repository.save(message);
    }

    public void deleteMessage(Long id) {
        repository.deleteById(id);
    }
}
