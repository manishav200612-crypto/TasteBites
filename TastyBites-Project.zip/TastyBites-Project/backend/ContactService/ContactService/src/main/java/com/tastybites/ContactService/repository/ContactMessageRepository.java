package com.tastybites.ContactService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tastybites.ContactService.entity.ContactMessage;

public interface ContactMessageRepository extends JpaRepository<ContactMessage, Long> {

}