package com.tastybites.ManagerService.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.tastybites.ManagerService.entity.Manager;
import com.tastybites.ManagerService.service.ManagerService;

@RestController
@RequestMapping("/api/managers")
public class ManagerController {

    private final ManagerService managerService;

    public ManagerController(ManagerService managerService) {
        this.managerService = managerService;
    }

    @GetMapping
    public List<Manager> getAllManagers() {
        return managerService.getAllManagers();
    }

    @PostMapping("/register")
    public ResponseEntity<Manager> registerManager(
            @RequestBody Manager manager) {

        Manager registeredManager =
                managerService.registerManager(manager);

        return ResponseEntity.ok(registeredManager);
    }

    @PostMapping("/login")
    public ResponseEntity<Manager> loginManager(
            @RequestBody Manager loginRequest) {

        Manager manager =
                managerService.loginManager(
                        loginRequest.getUsername(),
                        loginRequest.getPassword()
                );

        return ResponseEntity.ok(manager);
    }

    @GetMapping("/restaurant/{restaurantId}")
    public List<Manager> getManagersByRestaurant(
            @PathVariable Long restaurantId) {

        return managerService
                .getManagersByRestaurant(restaurantId);
    }
}