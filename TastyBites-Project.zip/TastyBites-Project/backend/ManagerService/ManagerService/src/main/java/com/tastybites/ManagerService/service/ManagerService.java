package com.tastybites.ManagerService.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.tastybites.ManagerService.entity.Manager;
import com.tastybites.ManagerService.repository.ManagerRepository;

@Service
public class ManagerService {

    private final ManagerRepository managerRepository;

    public ManagerService(ManagerRepository managerRepository) {
        this.managerRepository = managerRepository;
    }

    public List<Manager> getAllManagers() {
        return managerRepository.findAll();
    }

    public Manager registerManager(Manager manager) {

        if (managerRepository.existsByUsername(manager.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        return managerRepository.save(manager);
    }

    public Manager loginManager(String username, String password) {

        Optional<Manager> manager =
                managerRepository.findByUsernameAndPassword(
                        username,
                        password
                );

        if (manager.isPresent()) {
            return manager.get();
        }

        throw new RuntimeException("Invalid username or password");
    }

    public List<Manager> getManagersByRestaurant(Long restaurantId) {
        return managerRepository.findByRestaurantId(restaurantId);
    }
}
