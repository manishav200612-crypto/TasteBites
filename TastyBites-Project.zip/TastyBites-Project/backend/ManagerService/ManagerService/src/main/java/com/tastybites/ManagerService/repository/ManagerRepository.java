package com.tastybites.ManagerService.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tastybites.ManagerService.entity.Manager;

public interface ManagerRepository extends JpaRepository<Manager, Long> {

    Optional<Manager> findByUsernameAndPassword(
            String username,
            String password
    );

    boolean existsByUsername(String username);

    List<Manager> findByRestaurantId(Long restaurantId);
}