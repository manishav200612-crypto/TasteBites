package com.tastybites.MenuService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tastybites.MenuService.entity.MenuItem;

public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {

    List<MenuItem> findByRestaurantId(Long restaurantId);

}