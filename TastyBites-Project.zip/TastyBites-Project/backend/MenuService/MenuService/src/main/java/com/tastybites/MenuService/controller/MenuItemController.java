package com.tastybites.MenuService.controller;

import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tastybites.MenuService.entity.MenuItem;
import com.tastybites.MenuService.service.MenuItemService;

@RestController
@RequestMapping("/api/menu")
public class MenuItemController {

    private final MenuItemService menuItemService;

    public MenuItemController(MenuItemService menuItemService) {

        this.menuItemService = menuItemService;

    }

    @GetMapping
    public List<MenuItem> getAllMenuItems() {

        return menuItemService.getAllMenuItems();

    }

    // Get menu by restaurant
    @GetMapping("/restaurant/{restaurantId}")
    public List<MenuItem> getMenuByRestaurant(
            @PathVariable Long restaurantId) {

        return menuItemService.getMenuByRestaurant(restaurantId);

    }

    @PostMapping
    public MenuItem addMenuItem(@RequestBody MenuItem menuItem) {

        return menuItemService.addMenuItem(menuItem);

    }

    @DeleteMapping("/{id}")
    public void deleteMenuItem(@PathVariable Long id) {

        menuItemService.deleteMenuItem(id);

    }

    @PutMapping("/{id}")
    public MenuItem updateMenuItem(
            @PathVariable Long id,
            @RequestBody MenuItem menuItem) {

        return menuItemService.updateMenuItem(id, menuItem);

    }

}