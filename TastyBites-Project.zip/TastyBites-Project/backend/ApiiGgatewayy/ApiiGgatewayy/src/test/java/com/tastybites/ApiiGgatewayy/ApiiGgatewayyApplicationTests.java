package com.tastybites.ApiiGgatewayy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiiGgatewayyApplicationTests {

	@Test
	void contextLoads() {
	}

}
