package com.tastybites.ApiiGgatewayy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiiGgatewayyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiiGgatewayyApplication.class, args);
	}

}
