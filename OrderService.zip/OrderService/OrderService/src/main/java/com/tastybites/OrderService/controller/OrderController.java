package com.tastybites.OrderService.controller;

import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tastybites.OrderService.entity.Order;
import com.tastybites.OrderService.service.OrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }


    // =========================================
    // Get all orders
    // =========================================

    @GetMapping
    public List<Order> getAllOrders() {

        return orderService.getAllOrders();
    }


    // =========================================
    // Get orders by restaurant
    // =========================================

    @GetMapping("/restaurant/{restaurantId}")
    public List<Order> getOrdersByRestaurant(
            @PathVariable Long restaurantId) {

        return orderService.getOrdersByRestaurant(restaurantId);
    }
    
 // =========================================
 // Get orders by customer phone
 // =========================================

 @GetMapping("/customer/{phone}")
 public List<Order> getOrdersByCustomer(
         @PathVariable String phone) {

     return orderService.getOrdersByPhone(phone);
 }

    // =========================================
    // Add order
    // =========================================

    @PostMapping
    public Order addOrder(@RequestBody Order order) {

        return orderService.addOrder(order);
    }


    // =========================================
    // Delete order
    // =========================================

    @DeleteMapping("/{id}")
    public void deleteOrder(@PathVariable Long id) {

        orderService.deleteOrder(id);
    }


    // =========================================
    // Update order status
    // =========================================

    @PutMapping("/{id}/status")
    public Order updateOrderStatus(
            @PathVariable Long id,
            @RequestBody String status) {

        return orderService.updateOrderStatus(id, status);
    }


    // =========================================
    // Update delivery details
    // Date + Time + Duration
    // =========================================

    @PutMapping("/{id}/delivery")
    public Order updateDeliveryDetails(
            @PathVariable Long id,
            @RequestBody Map<String, String> deliveryRequest) {

        String deliveryDate =
                deliveryRequest.get("deliveryDate");

        String deliveryTime =
                deliveryRequest.get("deliveryTime");

        String durationText =
                deliveryRequest.get("deliveryDurationMinutes");

        Integer deliveryDurationMinutes =
                Integer.valueOf(durationText);


        return orderService.updateDeliveryDetails(
                id,
                deliveryDate,
                deliveryTime,
                deliveryDurationMinutes
        );
    }

}