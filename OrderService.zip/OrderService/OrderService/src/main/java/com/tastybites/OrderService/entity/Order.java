package com.tastybites.OrderService.entity;

import java.util.ArrayList;
import java.time.LocalDateTime;
import jakarta.persistence.Column;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerName;
    private String phone;
    private String foodName;
    private int quantity;
    private double totalPrice;
    private String address;
    private String status;
    private Long restaurantId;

    // Delivery details
    private String deliveryDate;
    private String deliveryTime;

    // Delivery duration in minutes
    private Integer deliveryDurationMinutes;

    @OneToMany(
        mappedBy = "order",
        cascade = CascadeType.ALL,
        orphanRemoval = true
    )
    @JsonManagedReference
    private List<OrderItem> orderItems = new ArrayList<>();
  
    @Column
    private LocalDateTime orderStartTime;
    public LocalDateTime getOrderStartTime() {
        return orderStartTime;
    }

    public void setOrderStartTime(LocalDateTime orderStartTime) {
        this.orderStartTime = orderStartTime;
    }

    // Default Constructor
    public Order() {
    }


    // Parameterized Constructor
    public Order(
            String customerName,
            String phone,
            String foodName,
            int quantity,
            double totalPrice,
            String address,
            String status,
            Long restaurantId) {

        this.customerName = customerName;
        this.phone = phone;
        this.foodName = foodName;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.address = address;
        this.status = status;
        this.restaurantId = restaurantId;
    }


    // Get ID
    public Long getId() {
        return id;
    }

    // Set ID
    public void setId(Long id) {
        this.id = id;
    }


    // Get Customer Name
    public String getCustomerName() {
        return customerName;
    }

    // Set Customer Name
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }


    // Get Phone
    public String getPhone() {
        return phone;
    }

    // Set Phone
    public void setPhone(String phone) {
        this.phone = phone;
    }


    // Get Food Name
    public String getFoodName() {
        return foodName;
    }

    // Set Food Name
    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }


    // Get Quantity
    public int getQuantity() {
        return quantity;
    }

    // Set Quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }


    // Get Total Price
    public double getTotalPrice() {
        return totalPrice;
    }

    // Set Total Price
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }


    // Get Address
    public String getAddress() {
        return address;
    }

    // Set Address
    public void setAddress(String address) {
        this.address = address;
    }


    // Get Status
    public String getStatus() {
        return status;
    }

    // Set Status
    public void setStatus(String status) {
        this.status = status;
    }


    // Get Restaurant ID
    public Long getRestaurantId() {
        return restaurantId;
    }

    // Set Restaurant ID
    public void setRestaurantId(Long restaurantId) {
        this.restaurantId = restaurantId;
    }


    // Get Delivery Date
    public String getDeliveryDate() {
        return deliveryDate;
    }

    // Set Delivery Date
    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }


    // Get Delivery Time
    public String getDeliveryTime() {
        return deliveryTime;
    }

    // Set Delivery Time
    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }


    // Get Delivery Duration
    public Integer getDeliveryDurationMinutes() {
        return deliveryDurationMinutes;
    }

    // Set Delivery Duration
    public void setDeliveryDurationMinutes(Integer deliveryDurationMinutes) {
        this.deliveryDurationMinutes = deliveryDurationMinutes;
    }


    // Get Order Items
    public List<OrderItem> getOrderItems() {
        return orderItems;
    }

    // Set Order Items
    public void setOrderItems(List<OrderItem> orderItems) {
        this.orderItems = orderItems;
    }

}