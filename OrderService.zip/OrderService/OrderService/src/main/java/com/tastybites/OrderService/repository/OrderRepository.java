package com.tastybites.OrderService.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tastybites.OrderService.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Long> {

    List<Order> findByRestaurantId(Long restaurantId);

    List<Order> findByPhone(String phone);

}