package com.tastybites.OrderService.service;

import java.time.Duration;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.tastybites.OrderService.entity.Order;
import com.tastybites.OrderService.repository.OrderRepository;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final SimpMessagingTemplate messagingTemplate;

    public OrderService(
            OrderRepository orderRepository,
            SimpMessagingTemplate messagingTemplate) {

        this.orderRepository = orderRepository;
        this.messagingTemplate = messagingTemplate;
    }

    // =========================================
    // GET ALL ORDERS
    // =========================================

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // =========================================
    // ADD ORDER
    // =========================================

    public Order addOrder(Order order) {

        if (order.getStatus() == null
                || order.getStatus().isBlank()) {
            order.setStatus("Pending");
        }

        if (order.getDeliveryDurationMinutes() == null
                || order.getDeliveryDurationMinutes() <= 0) {
            throw new IllegalArgumentException(
                    "Delivery duration must be greater than zero");
        }

        // Order start time
        order.setOrderStartTime(LocalDateTime.now());

        if (order.getOrderItems() != null) {
            for (var item : order.getOrderItems()) {
                item.setOrder(order);
            }
        }

        Order savedOrder = orderRepository.save(order);

        messagingTemplate.convertAndSend(
                "/topic/orders/" + savedOrder.getRestaurantId(),
                savedOrder
        );

        return savedOrder;
    }

    // =========================================
    // DELETE ORDER
    // =========================================

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    // =========================================
    // MANUAL STATUS UPDATE
    // =========================================

    public Order updateOrderStatus(Long id, String status) {

        Order order = orderRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Order not found"));

        order.setStatus(status);

        return orderRepository.save(order);
    }

    // =========================================
    // GET ORDERS BY RESTAURANT
    // =========================================

    public List<Order> getOrdersByRestaurant(Long restaurantId) {
        return orderRepository.findByRestaurantId(restaurantId);
    }

    // =========================================
    // GET ORDERS BY CUSTOMER PHONE
    // =========================================

    public List<Order> getOrdersByPhone(String phone) {
        return orderRepository.findByPhone(phone);
    }

    // =========================================
    // DELIVERY DATE, TIME & DURATION
    // =========================================

    public Order updateDeliveryDetails(
            Long id,
            String deliveryDate,
            String deliveryTime,
            Integer deliveryDurationMinutes) {

        Order order = orderRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Order not found"));

        if (deliveryDurationMinutes == null
                || deliveryDurationMinutes <= 0) {
            throw new IllegalArgumentException(
                    "Delivery duration must be greater than zero");
        }

        order.setDeliveryDate(deliveryDate);
        order.setDeliveryTime(deliveryTime);
        order.setDeliveryDurationMinutes(
                deliveryDurationMinutes);

        // Restart delivery flow from this time
        order.setOrderStartTime(LocalDateTime.now());
        order.setStatus("Pending");

        return orderRepository.save(order);
    }

    // =========================================
    // AUTOMATIC ORDER STATUS FLOW
    //
    // Pending
    //    ↓
    // Preparing
    //    ↓
    // Ready
    //    ↓
    // Out for Delivery
    //    ↓
    // Delivered
    //
    // Checks every 10 seconds
    // =========================================

    @Scheduled(fixedRate = 10000)
    public void checkAutomaticDelivery() {

        List<Order> orders = orderRepository.findAll();

        LocalDateTime now = LocalDateTime.now();

        for (Order order : orders) {

            Integer duration =
                    order.getDeliveryDurationMinutes();

            LocalDateTime startTime =
                    order.getOrderStartTime();

            // Required details must be present
            if (duration == null
                    || duration <= 0
                    || startTime == null) {
                continue;
            }

            // Do not process an already delivered order
            if ("Delivered".equalsIgnoreCase(order.getStatus())) {
                continue;
            }

            long totalSeconds = duration * 60L;

            long elapsedSeconds =
                    Duration.between(startTime, now).getSeconds();

            String newStatus;

            // Before the start time
            if (elapsedSeconds < 0) {
                newStatus = "Pending";
            }

            // 0% - 20%
            else if (elapsedSeconds < totalSeconds * 0.20) {
                newStatus = "Pending";
            }

            // 20% - 50%
            else if (elapsedSeconds < totalSeconds * 0.50) {
                newStatus = "Preparing";
            }

            // 50% - 80%
            else if (elapsedSeconds < totalSeconds * 0.80) {
                newStatus = "Ready";
            }

            // 80% - 100%
            else if (elapsedSeconds < totalSeconds) {
                newStatus = "Out for Delivery";
            }

            // 100% complete
            else {
                newStatus = "Delivered";
            }

            // Save only when status changes
            if (order.getStatus() == null
                    || !newStatus.equalsIgnoreCase(
                            order.getStatus())) {

                order.setStatus(newStatus);
                orderRepository.save(order);

                System.out.println(
                        "Order #" + order.getId()
                        + " | Duration: " + duration + " minutes"
                        + " | Elapsed: " + elapsedSeconds + " seconds"
                        + " | Status: " + newStatus);
            }
        }
    }
}